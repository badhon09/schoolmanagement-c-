﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SchoolManagementSystemOOP2.Service;
using System.Data.SqlClient;

namespace SchoolManagementSystemOOP2.student
{
    public partial class CheckNotice : Form
    {
        private DataAccess Da { set; get; }
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-C8UR0SS;Initial Catalog=SchoolManagement;Integrated Security=True");
        private SqlDataAdapter Rda { set; get; }
        SqlDataReader dr;
        SqlCommand cmd;
        public CheckNotice()
        {
            cmd = new SqlCommand();
            Da = new DataAccess();
            InitializeComponent();
            DisplayData();
            classCombobox();
        }
        public void classCombobox()
        {
            // cmbClass.Items.Clear();

            string sql = "select * from student where username='" + global.UserName + "' ";

            cmd = new SqlCommand(sql, con);
            SqlDataReader rd;
            try
            {
                con.Open();
                rd = cmd.ExecuteReader();
                while (rd.Read())
                {
                    string cname = rd.GetString(13);
                    cmbClass.Items.Add(cname);
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            con.Close();
        }

        public void DisplayData()
        {
            /*DataSet ds = Da.ExecuteQuery("select * from notice where class = '" + cmbClass.Text + "'");
             this.dgv.AutoGenerateColumns = false;
            this.dgv.DataSource = ds.Tables[0];
            */
        }
        private void CheckNotice_Load(object sender, EventArgs e)
        {

        }
    }
}
