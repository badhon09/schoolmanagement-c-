﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SchoolManagementSystemOOP2.TeachingModule;
using SchoolManagementSystemOOP2.admin;
using SchoolManagementSystemOOP2.Service;
using SchoolManagementSystemOOP2.ui;


namespace SchoolManagementSystemOOP2
{
    public partial class AdminDashboard : Form
    {
        DataAccess Da { set; get; }
        public AdminDashboard()
        {
            InitializeComponent();
            Da = new DataAccess();
          //  DisplayData();
        }

        private void bunifuFlatButton3_Click(object sender, EventArgs e)
        {

        }

        private void bunifuFlatButton8_Click(object sender, EventArgs e)
        {

        }

        private void sidebar_Paint(object sender, PaintEventArgs e)
        {

        }

        private void bunifuFlatButton1_Click(object sender, EventArgs e)
        {
            //Container ccc = new Container();
           // ShowForm(ccc);
        }

        private void bunifuFlatButton3_Click_1(object sender, EventArgs e)
        {
            container.Controls.Clear();
            Students std = new Students();
            std.TopLevel = false;
            container.Controls.Add(std);
            std.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            std.Dock = DockStyle.Fill;
            std.Show();


        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void bunifuFlatButton4_Click(object sender, EventArgs e)
        {
            
            TeachingStaff ts = new TeachingStaff();
            ShowForm(ts);

         

        }

        private void ShowForm(Form frm)
        {
            container.Controls.Clear();
            frm.TopLevel = false;
            container.Controls.Add(frm);
            frm.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            frm.Dock = DockStyle.Fill;
            frm.Show();

        }

        private void ShowControl(Control controls)
        {
            container.Controls.Clear();
            //.TopLevel = false;
            container.Controls.Add(controls);
            //frm.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            controls.Dock = DockStyle.Fill;
            controls.Show();

        }
       


        private void btnClasses_Click(object sender, EventArgs e)
        {
            frmClasses cc = new frmClasses();
            ShowControl(cc);
        }

        private void container_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnSubjects_Click(object sender, EventArgs e)
        {
            frmSubjects sub = new frmSubjects();
            ShowForm(sub);
        }

        private void bunifuFlatButton7_Click(object sender, EventArgs e)
        {
            frmSection s = new frmSection();
            ShowForm(s);
        }

        private void txtUsers_Click(object sender, EventArgs e)
        {
            AdminList al = new AdminList();
            ShowForm(al);
        }

        private void btnClassRoutine_Click(object sender, EventArgs e)
        {
            ClassSchedule cs = new ClassSchedule();
            ShowForm(cs);
        }

        private void AdminDashboard_Load(object sender, EventArgs e)
        {
            lblUsername.Text = global.UserName;
        }

        private void bunifuTileButton2_Click(object sender, EventArgs e)
        {
            TeachingStaff ts = new TeachingStaff();
            ShowForm(ts);
        }

        private void bunifuTileButton3_Click(object sender, EventArgs e)
        {
            frmSubjects sub = new frmSubjects();
            ShowForm(sub);
        }

        private void bunifuTileButton4_Click(object sender, EventArgs e)
        {
            frmClasses cc = new frmClasses();
            ShowControl(cc);
        }

        private void bunifuTileButton5_Click(object sender, EventArgs e)
        {
            ClassSchedule cs = new ClassSchedule();
            ShowForm(cs);
        }

        private void bunifuTileButton6_Click(object sender, EventArgs e)
        {
            frmSection s = new frmSection();
            ShowForm(s);
        }

        private void bunifuFlatButton1_Click_1(object sender, EventArgs e)
        {
            Login l = new Login();
            this.Hide();
            l.Show();
        }
    }
}
