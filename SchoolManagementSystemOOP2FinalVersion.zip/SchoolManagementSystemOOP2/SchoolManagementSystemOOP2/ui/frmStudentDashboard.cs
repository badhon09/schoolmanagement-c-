﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SchoolManagementSystemOOP2.student;
using System.Data.SqlClient;
using SchoolManagementSystemOOP2.Service;

namespace SchoolManagementSystemOOP2.ui
{
    public partial class frmStudentDashboard : Form
    {
        public frmStudentDashboard()
        {
            InitializeComponent();
        }

        private void frmStudentDashboard_Load(object sender, EventArgs e)
        {
            lblUsername.Text = global.UserName;
        }
        private void ShowForm(Form frm)
        {
            container.Controls.Clear();
            frm.TopLevel = false;
            container.Controls.Add(frm);
            frm.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            frm.Dock = DockStyle.Fill;
            frm.Show();

        }

        private void bunifuFlatButton2_Click(object sender, EventArgs e)
        {
            ViewRoutine vr = new ViewRoutine();
            ShowForm(vr);
        }

        private void btnTeachingStaff_Click(object sender, EventArgs e)
        {
            CheckResult cr = new CheckResult();
            ShowForm(cr);
        }

        private void bunifuTileButton4_Click(object sender, EventArgs e)
        {
            Login l = new Login();
            this.Hide();
            l.Show();
            
        }

        private void bunifuFlatButton3_Click(object sender, EventArgs e)
        {
            Login l = new Login();
            this.Hide();
            l.Show();

        }

        private void bunifuTileButton1_Click(object sender, EventArgs e)
        {
            CheckNotice cn = new CheckNotice();
            ShowForm(cn);

        }

        private void bunifuTileButton3_Click(object sender, EventArgs e)
        {
            ViewRoutine vr = new ViewRoutine();
            ShowForm(vr);
        }

        private void bunifuTileButton2_Click(object sender, EventArgs e)
        {
            CheckResult cr = new CheckResult();
            ShowForm(cr);
        }

        private void bunifuFlatButton1_Click(object sender, EventArgs e)
        {
            CheckNotice cn = new CheckNotice();
            ShowForm(cn);
        }
    }
}
