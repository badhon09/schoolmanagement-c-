﻿namespace SchoolManagementSystemOOP2
{
    partial class AdminDashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AdminDashboard));
            this.sidebar = new System.Windows.Forms.Panel();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.logo = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnSections = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnSubjects = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnClasses = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnTeachingStaff = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnStudents = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnDashboard = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnClassRoutine = new Bunifu.Framework.UI.BunifuFlatButton();
            this.txtUsers = new Bunifu.Framework.UI.BunifuFlatButton();
            this.bunifuFlatButton1 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.top = new System.Windows.Forms.Panel();
            this.lblUsername = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.container = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.bunifuTileButton6 = new Bunifu.Framework.UI.BunifuTileButton();
            this.panel5 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.bunifuTileButton5 = new Bunifu.Framework.UI.BunifuTileButton();
            this.bunifuTileButton4 = new Bunifu.Framework.UI.BunifuTileButton();
            this.bunifuTileButton3 = new Bunifu.Framework.UI.BunifuTileButton();
            this.bunifuTileButton2 = new Bunifu.Framework.UI.BunifuTileButton();
            this.bunifuTileButton1 = new Bunifu.Framework.UI.BunifuTileButton();
            this.sidebar.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.logo.SuspendLayout();
            this.top.SuspendLayout();
            this.container.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel5.SuspendLayout();
            this.SuspendLayout();
            // 
            // sidebar
            // 
            this.sidebar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(6)))), ((int)(((byte)(55)))), ((int)(((byte)(98)))));
            this.sidebar.Controls.Add(this.tableLayoutPanel1);
            this.sidebar.Dock = System.Windows.Forms.DockStyle.Left;
            this.sidebar.Location = new System.Drawing.Point(0, 0);
            this.sidebar.Name = "sidebar";
            this.sidebar.Size = new System.Drawing.Size(206, 630);
            this.sidebar.TabIndex = 0;
            this.sidebar.Paint += new System.Windows.Forms.PaintEventHandler(this.sidebar_Paint);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(52)))), ((int)(((byte)(85)))));
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.logo, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.btnSections, 0, 6);
            this.tableLayoutPanel1.Controls.Add(this.btnSubjects, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.btnClasses, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.btnTeachingStaff, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.btnStudents, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.btnDashboard, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.btnClassRoutine, 0, 7);
            this.tableLayoutPanel1.Controls.Add(this.txtUsers, 0, 8);
            this.tableLayoutPanel1.Controls.Add(this.bunifuFlatButton1, 0, 9);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 12;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 46F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 8F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(206, 630);
            this.tableLayoutPanel1.TabIndex = 1;
            this.tableLayoutPanel1.Paint += new System.Windows.Forms.PaintEventHandler(this.tableLayoutPanel1_Paint);
            // 
            // logo
            // 
            this.logo.Controls.Add(this.label2);
            this.logo.Controls.Add(this.label1);
            this.logo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.logo.Location = new System.Drawing.Point(3, 3);
            this.logo.Name = "logo";
            this.logo.Size = new System.Drawing.Size(200, 94);
            this.logo.TabIndex = 0;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label2.Location = new System.Drawing.Point(37, 47);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(121, 38);
            this.label2.TabIndex = 12;
            this.label2.Text = "School";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(25, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(143, 32);
            this.label1.TabIndex = 11;
            this.label1.Text = "American";
            // 
            // btnSections
            // 
            this.btnSections.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.btnSections.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(6)))), ((int)(((byte)(55)))), ((int)(((byte)(98)))));
            this.btnSections.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnSections.BorderRadius = 0;
            this.btnSections.ButtonText = "Sections";
            this.btnSections.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSections.DisabledColor = System.Drawing.Color.Gray;
            this.btnSections.Iconcolor = System.Drawing.Color.Transparent;
            this.btnSections.Iconimage = null;
            this.btnSections.Iconimage_right = null;
            this.btnSections.Iconimage_right_Selected = null;
            this.btnSections.Iconimage_Selected = null;
            this.btnSections.IconMarginLeft = 0;
            this.btnSections.IconMarginRight = 0;
            this.btnSections.IconRightVisible = true;
            this.btnSections.IconRightZoom = 0D;
            this.btnSections.IconVisible = true;
            this.btnSections.IconZoom = 90D;
            this.btnSections.IsTab = false;
            this.btnSections.Location = new System.Drawing.Point(3, 353);
            this.btnSections.Name = "btnSections";
            this.btnSections.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(6)))), ((int)(((byte)(55)))), ((int)(((byte)(98)))));
            this.btnSections.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.btnSections.OnHoverTextColor = System.Drawing.Color.White;
            this.btnSections.selected = false;
            this.btnSections.Size = new System.Drawing.Size(194, 44);
            this.btnSections.TabIndex = 6;
            this.btnSections.Text = "Sections";
            this.btnSections.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSections.Textcolor = System.Drawing.Color.White;
            this.btnSections.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSections.Click += new System.EventHandler(this.bunifuFlatButton7_Click);
            // 
            // btnSubjects
            // 
            this.btnSubjects.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.btnSubjects.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(6)))), ((int)(((byte)(55)))), ((int)(((byte)(98)))));
            this.btnSubjects.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnSubjects.BorderRadius = 0;
            this.btnSubjects.ButtonText = "Subjects";
            this.btnSubjects.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSubjects.DisabledColor = System.Drawing.Color.Gray;
            this.btnSubjects.Iconcolor = System.Drawing.Color.Transparent;
            this.btnSubjects.Iconimage = null;
            this.btnSubjects.Iconimage_right = null;
            this.btnSubjects.Iconimage_right_Selected = null;
            this.btnSubjects.Iconimage_Selected = null;
            this.btnSubjects.IconMarginLeft = 0;
            this.btnSubjects.IconMarginRight = 0;
            this.btnSubjects.IconRightVisible = true;
            this.btnSubjects.IconRightZoom = 0D;
            this.btnSubjects.IconVisible = true;
            this.btnSubjects.IconZoom = 90D;
            this.btnSubjects.IsTab = false;
            this.btnSubjects.Location = new System.Drawing.Point(3, 303);
            this.btnSubjects.Name = "btnSubjects";
            this.btnSubjects.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(6)))), ((int)(((byte)(55)))), ((int)(((byte)(98)))));
            this.btnSubjects.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.btnSubjects.OnHoverTextColor = System.Drawing.Color.White;
            this.btnSubjects.selected = false;
            this.btnSubjects.Size = new System.Drawing.Size(194, 44);
            this.btnSubjects.TabIndex = 5;
            this.btnSubjects.Text = "Subjects";
            this.btnSubjects.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSubjects.Textcolor = System.Drawing.Color.White;
            this.btnSubjects.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSubjects.Click += new System.EventHandler(this.btnSubjects_Click);
            // 
            // btnClasses
            // 
            this.btnClasses.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.btnClasses.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(6)))), ((int)(((byte)(55)))), ((int)(((byte)(98)))));
            this.btnClasses.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnClasses.BorderRadius = 0;
            this.btnClasses.ButtonText = "Classes";
            this.btnClasses.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnClasses.DisabledColor = System.Drawing.Color.Gray;
            this.btnClasses.Iconcolor = System.Drawing.Color.Transparent;
            this.btnClasses.Iconimage = null;
            this.btnClasses.Iconimage_right = null;
            this.btnClasses.Iconimage_right_Selected = null;
            this.btnClasses.Iconimage_Selected = null;
            this.btnClasses.IconMarginLeft = 0;
            this.btnClasses.IconMarginRight = 0;
            this.btnClasses.IconRightVisible = true;
            this.btnClasses.IconRightZoom = 0D;
            this.btnClasses.IconVisible = true;
            this.btnClasses.IconZoom = 90D;
            this.btnClasses.IsTab = false;
            this.btnClasses.Location = new System.Drawing.Point(3, 253);
            this.btnClasses.Name = "btnClasses";
            this.btnClasses.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(6)))), ((int)(((byte)(55)))), ((int)(((byte)(98)))));
            this.btnClasses.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.btnClasses.OnHoverTextColor = System.Drawing.Color.White;
            this.btnClasses.selected = false;
            this.btnClasses.Size = new System.Drawing.Size(194, 44);
            this.btnClasses.TabIndex = 4;
            this.btnClasses.Text = "Classes";
            this.btnClasses.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnClasses.Textcolor = System.Drawing.Color.White;
            this.btnClasses.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClasses.Click += new System.EventHandler(this.btnClasses_Click);
            // 
            // btnTeachingStaff
            // 
            this.btnTeachingStaff.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.btnTeachingStaff.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(6)))), ((int)(((byte)(55)))), ((int)(((byte)(98)))));
            this.btnTeachingStaff.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnTeachingStaff.BorderRadius = 0;
            this.btnTeachingStaff.ButtonText = "Teaching Staff";
            this.btnTeachingStaff.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnTeachingStaff.DisabledColor = System.Drawing.Color.Gray;
            this.btnTeachingStaff.Iconcolor = System.Drawing.Color.Transparent;
            this.btnTeachingStaff.Iconimage = null;
            this.btnTeachingStaff.Iconimage_right = null;
            this.btnTeachingStaff.Iconimage_right_Selected = null;
            this.btnTeachingStaff.Iconimage_Selected = null;
            this.btnTeachingStaff.IconMarginLeft = 0;
            this.btnTeachingStaff.IconMarginRight = 0;
            this.btnTeachingStaff.IconRightVisible = true;
            this.btnTeachingStaff.IconRightZoom = 0D;
            this.btnTeachingStaff.IconVisible = true;
            this.btnTeachingStaff.IconZoom = 90D;
            this.btnTeachingStaff.IsTab = false;
            this.btnTeachingStaff.Location = new System.Drawing.Point(3, 203);
            this.btnTeachingStaff.Name = "btnTeachingStaff";
            this.btnTeachingStaff.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(6)))), ((int)(((byte)(55)))), ((int)(((byte)(98)))));
            this.btnTeachingStaff.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.btnTeachingStaff.OnHoverTextColor = System.Drawing.Color.White;
            this.btnTeachingStaff.selected = false;
            this.btnTeachingStaff.Size = new System.Drawing.Size(194, 44);
            this.btnTeachingStaff.TabIndex = 3;
            this.btnTeachingStaff.Text = "Teaching Staff";
            this.btnTeachingStaff.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnTeachingStaff.Textcolor = System.Drawing.Color.White;
            this.btnTeachingStaff.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTeachingStaff.Click += new System.EventHandler(this.bunifuFlatButton4_Click);
            // 
            // btnStudents
            // 
            this.btnStudents.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.btnStudents.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(6)))), ((int)(((byte)(55)))), ((int)(((byte)(98)))));
            this.btnStudents.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnStudents.BorderRadius = 4;
            this.btnStudents.ButtonText = "Students";
            this.btnStudents.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnStudents.DisabledColor = System.Drawing.Color.Gray;
            this.btnStudents.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnStudents.Iconcolor = System.Drawing.Color.Transparent;
            this.btnStudents.Iconimage = ((System.Drawing.Image)(resources.GetObject("btnStudents.Iconimage")));
            this.btnStudents.Iconimage_right = null;
            this.btnStudents.Iconimage_right_Selected = null;
            this.btnStudents.Iconimage_Selected = null;
            this.btnStudents.IconMarginLeft = 0;
            this.btnStudents.IconMarginRight = 0;
            this.btnStudents.IconRightVisible = true;
            this.btnStudents.IconRightZoom = 0D;
            this.btnStudents.IconVisible = true;
            this.btnStudents.IconZoom = 90D;
            this.btnStudents.IsTab = false;
            this.btnStudents.Location = new System.Drawing.Point(3, 153);
            this.btnStudents.Name = "btnStudents";
            this.btnStudents.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(6)))), ((int)(((byte)(55)))), ((int)(((byte)(98)))));
            this.btnStudents.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.btnStudents.OnHoverTextColor = System.Drawing.Color.White;
            this.btnStudents.selected = false;
            this.btnStudents.Size = new System.Drawing.Size(200, 44);
            this.btnStudents.TabIndex = 2;
            this.btnStudents.Text = "Students";
            this.btnStudents.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnStudents.Textcolor = System.Drawing.Color.White;
            this.btnStudents.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnStudents.Click += new System.EventHandler(this.bunifuFlatButton3_Click_1);
            // 
            // btnDashboard
            // 
            this.btnDashboard.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.btnDashboard.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(6)))), ((int)(((byte)(55)))), ((int)(((byte)(98)))));
            this.btnDashboard.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnDashboard.BorderRadius = 0;
            this.btnDashboard.ButtonText = "Dashboard ";
            this.btnDashboard.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDashboard.DisabledColor = System.Drawing.Color.Gray;
            this.btnDashboard.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnDashboard.Iconcolor = System.Drawing.Color.Transparent;
            this.btnDashboard.Iconimage = null;
            this.btnDashboard.Iconimage_right = null;
            this.btnDashboard.Iconimage_right_Selected = null;
            this.btnDashboard.Iconimage_Selected = null;
            this.btnDashboard.IconMarginLeft = 0;
            this.btnDashboard.IconMarginRight = 0;
            this.btnDashboard.IconRightVisible = true;
            this.btnDashboard.IconRightZoom = 0D;
            this.btnDashboard.IconVisible = true;
            this.btnDashboard.IconZoom = 90D;
            this.btnDashboard.IsTab = false;
            this.btnDashboard.Location = new System.Drawing.Point(3, 103);
            this.btnDashboard.Name = "btnDashboard";
            this.btnDashboard.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(6)))), ((int)(((byte)(55)))), ((int)(((byte)(98)))));
            this.btnDashboard.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.btnDashboard.OnHoverTextColor = System.Drawing.Color.White;
            this.btnDashboard.selected = false;
            this.btnDashboard.Size = new System.Drawing.Size(200, 44);
            this.btnDashboard.TabIndex = 0;
            this.btnDashboard.Text = "Dashboard ";
            this.btnDashboard.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDashboard.Textcolor = System.Drawing.Color.White;
            this.btnDashboard.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDashboard.Click += new System.EventHandler(this.bunifuFlatButton1_Click);
            // 
            // btnClassRoutine
            // 
            this.btnClassRoutine.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.btnClassRoutine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(6)))), ((int)(((byte)(55)))), ((int)(((byte)(98)))));
            this.btnClassRoutine.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnClassRoutine.BorderRadius = 0;
            this.btnClassRoutine.ButtonText = "Class Routine";
            this.btnClassRoutine.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnClassRoutine.DisabledColor = System.Drawing.Color.Gray;
            this.btnClassRoutine.Iconcolor = System.Drawing.Color.Transparent;
            this.btnClassRoutine.Iconimage = null;
            this.btnClassRoutine.Iconimage_right = null;
            this.btnClassRoutine.Iconimage_right_Selected = null;
            this.btnClassRoutine.Iconimage_Selected = null;
            this.btnClassRoutine.IconMarginLeft = 0;
            this.btnClassRoutine.IconMarginRight = 0;
            this.btnClassRoutine.IconRightVisible = true;
            this.btnClassRoutine.IconRightZoom = 0D;
            this.btnClassRoutine.IconVisible = true;
            this.btnClassRoutine.IconZoom = 90D;
            this.btnClassRoutine.IsTab = false;
            this.btnClassRoutine.Location = new System.Drawing.Point(3, 403);
            this.btnClassRoutine.Name = "btnClassRoutine";
            this.btnClassRoutine.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(6)))), ((int)(((byte)(55)))), ((int)(((byte)(98)))));
            this.btnClassRoutine.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.btnClassRoutine.OnHoverTextColor = System.Drawing.Color.White;
            this.btnClassRoutine.selected = false;
            this.btnClassRoutine.Size = new System.Drawing.Size(194, 44);
            this.btnClassRoutine.TabIndex = 8;
            this.btnClassRoutine.Text = "Class Routine";
            this.btnClassRoutine.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnClassRoutine.Textcolor = System.Drawing.Color.White;
            this.btnClassRoutine.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClassRoutine.Click += new System.EventHandler(this.btnClassRoutine_Click);
            // 
            // txtUsers
            // 
            this.txtUsers.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.txtUsers.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(6)))), ((int)(((byte)(55)))), ((int)(((byte)(98)))));
            this.txtUsers.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.txtUsers.BorderRadius = 0;
            this.txtUsers.ButtonText = "Users";
            this.txtUsers.Cursor = System.Windows.Forms.Cursors.Hand;
            this.txtUsers.DisabledColor = System.Drawing.Color.Gray;
            this.txtUsers.Iconcolor = System.Drawing.Color.Transparent;
            this.txtUsers.Iconimage = null;
            this.txtUsers.Iconimage_right = null;
            this.txtUsers.Iconimage_right_Selected = null;
            this.txtUsers.Iconimage_Selected = null;
            this.txtUsers.IconMarginLeft = 0;
            this.txtUsers.IconMarginRight = 0;
            this.txtUsers.IconRightVisible = true;
            this.txtUsers.IconRightZoom = 0D;
            this.txtUsers.IconVisible = true;
            this.txtUsers.IconZoom = 90D;
            this.txtUsers.IsTab = false;
            this.txtUsers.Location = new System.Drawing.Point(3, 453);
            this.txtUsers.Name = "txtUsers";
            this.txtUsers.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(6)))), ((int)(((byte)(55)))), ((int)(((byte)(98)))));
            this.txtUsers.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.txtUsers.OnHoverTextColor = System.Drawing.Color.White;
            this.txtUsers.selected = false;
            this.txtUsers.Size = new System.Drawing.Size(194, 44);
            this.txtUsers.TabIndex = 7;
            this.txtUsers.Text = "Users";
            this.txtUsers.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.txtUsers.Textcolor = System.Drawing.Color.White;
            this.txtUsers.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtUsers.Click += new System.EventHandler(this.txtUsers_Click);
            // 
            // bunifuFlatButton1
            // 
            this.bunifuFlatButton1.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.bunifuFlatButton1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.bunifuFlatButton1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton1.BorderRadius = 0;
            this.bunifuFlatButton1.ButtonText = "Log Out";
            this.bunifuFlatButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton1.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton1.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton1.Iconimage = null;
            this.bunifuFlatButton1.Iconimage_right = null;
            this.bunifuFlatButton1.Iconimage_right_Selected = null;
            this.bunifuFlatButton1.Iconimage_Selected = null;
            this.bunifuFlatButton1.IconMarginLeft = 0;
            this.bunifuFlatButton1.IconMarginRight = 0;
            this.bunifuFlatButton1.IconRightVisible = true;
            this.bunifuFlatButton1.IconRightZoom = 0D;
            this.bunifuFlatButton1.IconVisible = true;
            this.bunifuFlatButton1.IconZoom = 90D;
            this.bunifuFlatButton1.IsTab = false;
            this.bunifuFlatButton1.Location = new System.Drawing.Point(3, 503);
            this.bunifuFlatButton1.Name = "bunifuFlatButton1";
            this.bunifuFlatButton1.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.bunifuFlatButton1.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.bunifuFlatButton1.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton1.selected = false;
            this.bunifuFlatButton1.Size = new System.Drawing.Size(194, 44);
            this.bunifuFlatButton1.TabIndex = 9;
            this.bunifuFlatButton1.Text = "Log Out";
            this.bunifuFlatButton1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bunifuFlatButton1.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton1.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuFlatButton1.Click += new System.EventHandler(this.bunifuFlatButton1_Click_1);
            // 
            // top
            // 
            this.top.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(52)))), ((int)(((byte)(85)))));
            this.top.Controls.Add(this.lblUsername);
            this.top.Controls.Add(this.label3);
            this.top.Dock = System.Windows.Forms.DockStyle.Top;
            this.top.Location = new System.Drawing.Point(206, 0);
            this.top.Name = "top";
            this.top.Size = new System.Drawing.Size(983, 52);
            this.top.TabIndex = 1;
            // 
            // lblUsername
            // 
            this.lblUsername.AutoSize = true;
            this.lblUsername.Font = new System.Drawing.Font("Microsoft YaHei UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUsername.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblUsername.Location = new System.Drawing.Point(821, 9);
            this.lblUsername.Name = "lblUsername";
            this.lblUsername.Size = new System.Drawing.Size(108, 26);
            this.lblUsername.TabIndex = 1;
            this.lblUsername.Text = "Username";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft YaHei UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label3.Location = new System.Drawing.Point(703, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(112, 26);
            this.label3.TabIndex = 0;
            this.label3.Text = "Welcome :";
            // 
            // container
            // 
            this.container.BackColor = System.Drawing.SystemColors.Control;
            this.container.Controls.Add(this.panel1);
            this.container.Dock = System.Windows.Forms.DockStyle.Fill;
            this.container.Location = new System.Drawing.Point(206, 52);
            this.container.Name = "container";
            this.container.Size = new System.Drawing.Size(983, 578);
            this.container.TabIndex = 2;
            this.container.Paint += new System.Windows.Forms.PaintEventHandler(this.container_Paint);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.bunifuTileButton6);
            this.panel1.Controls.Add(this.panel5);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.bunifuTileButton5);
            this.panel1.Controls.Add(this.bunifuTileButton4);
            this.panel1.Controls.Add(this.bunifuTileButton3);
            this.panel1.Controls.Add(this.bunifuTileButton2);
            this.panel1.Controls.Add(this.bunifuTileButton1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(983, 578);
            this.panel1.TabIndex = 0;
            // 
            // bunifuTileButton6
            // 
            this.bunifuTileButton6.BackColor = System.Drawing.Color.SeaGreen;
            this.bunifuTileButton6.color = System.Drawing.Color.SeaGreen;
            this.bunifuTileButton6.colorActive = System.Drawing.Color.MediumSeaGreen;
            this.bunifuTileButton6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuTileButton6.Font = new System.Drawing.Font("Century Gothic", 15.75F);
            this.bunifuTileButton6.ForeColor = System.Drawing.Color.White;
            this.bunifuTileButton6.Image = ((System.Drawing.Image)(resources.GetObject("bunifuTileButton6.Image")));
            this.bunifuTileButton6.ImagePosition = 20;
            this.bunifuTileButton6.ImageZoom = 50;
            this.bunifuTileButton6.LabelPosition = 41;
            this.bunifuTileButton6.LabelText = "Section";
            this.bunifuTileButton6.Location = new System.Drawing.Point(544, 401);
            this.bunifuTileButton6.Margin = new System.Windows.Forms.Padding(6);
            this.bunifuTileButton6.Name = "bunifuTileButton6";
            this.bunifuTileButton6.Size = new System.Drawing.Size(211, 159);
            this.bunifuTileButton6.TabIndex = 24;
            this.bunifuTileButton6.Click += new System.EventHandler(this.bunifuTileButton6_Click);
            // 
            // panel5
            // 
            this.panel5.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel5.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel5.Controls.Add(this.label4);
            this.panel5.Location = new System.Drawing.Point(1, 51);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(982, 112);
            this.panel5.TabIndex = 22;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label4.Location = new System.Drawing.Point(347, 37);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(186, 38);
            this.label4.TabIndex = 14;
            this.label4.Text = "Dashboard";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Century Gothic", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label7.Location = new System.Drawing.Point(231, 13);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(405, 32);
            this.label7.TabIndex = 23;
            this.label7.Text = "Welcome To American School";
            // 
            // bunifuTileButton5
            // 
            this.bunifuTileButton5.BackColor = System.Drawing.Color.SeaGreen;
            this.bunifuTileButton5.color = System.Drawing.Color.SeaGreen;
            this.bunifuTileButton5.colorActive = System.Drawing.Color.MediumSeaGreen;
            this.bunifuTileButton5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuTileButton5.Font = new System.Drawing.Font("Century Gothic", 15.75F);
            this.bunifuTileButton5.ForeColor = System.Drawing.Color.White;
            this.bunifuTileButton5.Image = ((System.Drawing.Image)(resources.GetObject("bunifuTileButton5.Image")));
            this.bunifuTileButton5.ImagePosition = 20;
            this.bunifuTileButton5.ImageZoom = 50;
            this.bunifuTileButton5.LabelPosition = 41;
            this.bunifuTileButton5.LabelText = "Class Routine";
            this.bunifuTileButton5.Location = new System.Drawing.Point(544, 192);
            this.bunifuTileButton5.Margin = new System.Windows.Forms.Padding(6);
            this.bunifuTileButton5.Name = "bunifuTileButton5";
            this.bunifuTileButton5.Size = new System.Drawing.Size(211, 170);
            this.bunifuTileButton5.TabIndex = 5;
            this.bunifuTileButton5.Click += new System.EventHandler(this.bunifuTileButton5_Click);
            // 
            // bunifuTileButton4
            // 
            this.bunifuTileButton4.BackColor = System.Drawing.Color.SeaGreen;
            this.bunifuTileButton4.color = System.Drawing.Color.SeaGreen;
            this.bunifuTileButton4.colorActive = System.Drawing.Color.MediumSeaGreen;
            this.bunifuTileButton4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuTileButton4.Font = new System.Drawing.Font("Century Gothic", 15.75F);
            this.bunifuTileButton4.ForeColor = System.Drawing.Color.White;
            this.bunifuTileButton4.Image = ((System.Drawing.Image)(resources.GetObject("bunifuTileButton4.Image")));
            this.bunifuTileButton4.ImagePosition = 20;
            this.bunifuTileButton4.ImageZoom = 50;
            this.bunifuTileButton4.LabelPosition = 41;
            this.bunifuTileButton4.LabelText = "Class";
            this.bunifuTileButton4.Location = new System.Drawing.Point(277, 403);
            this.bunifuTileButton4.Margin = new System.Windows.Forms.Padding(6);
            this.bunifuTileButton4.Name = "bunifuTileButton4";
            this.bunifuTileButton4.Size = new System.Drawing.Size(211, 159);
            this.bunifuTileButton4.TabIndex = 4;
            this.bunifuTileButton4.Click += new System.EventHandler(this.bunifuTileButton4_Click);
            // 
            // bunifuTileButton3
            // 
            this.bunifuTileButton3.BackColor = System.Drawing.Color.SeaGreen;
            this.bunifuTileButton3.color = System.Drawing.Color.SeaGreen;
            this.bunifuTileButton3.colorActive = System.Drawing.Color.MediumSeaGreen;
            this.bunifuTileButton3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuTileButton3.Font = new System.Drawing.Font("Century Gothic", 15.75F);
            this.bunifuTileButton3.ForeColor = System.Drawing.Color.White;
            this.bunifuTileButton3.Image = ((System.Drawing.Image)(resources.GetObject("bunifuTileButton3.Image")));
            this.bunifuTileButton3.ImagePosition = 20;
            this.bunifuTileButton3.ImageZoom = 50;
            this.bunifuTileButton3.LabelPosition = 41;
            this.bunifuTileButton3.LabelText = "Subjects";
            this.bunifuTileButton3.Location = new System.Drawing.Point(22, 403);
            this.bunifuTileButton3.Margin = new System.Windows.Forms.Padding(6);
            this.bunifuTileButton3.Name = "bunifuTileButton3";
            this.bunifuTileButton3.Size = new System.Drawing.Size(204, 159);
            this.bunifuTileButton3.TabIndex = 3;
            this.bunifuTileButton3.Click += new System.EventHandler(this.bunifuTileButton3_Click);
            // 
            // bunifuTileButton2
            // 
            this.bunifuTileButton2.BackColor = System.Drawing.Color.SeaGreen;
            this.bunifuTileButton2.color = System.Drawing.Color.SeaGreen;
            this.bunifuTileButton2.colorActive = System.Drawing.Color.MediumSeaGreen;
            this.bunifuTileButton2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuTileButton2.Font = new System.Drawing.Font("Century Gothic", 15.75F);
            this.bunifuTileButton2.ForeColor = System.Drawing.Color.White;
            this.bunifuTileButton2.Image = ((System.Drawing.Image)(resources.GetObject("bunifuTileButton2.Image")));
            this.bunifuTileButton2.ImagePosition = 20;
            this.bunifuTileButton2.ImageZoom = 50;
            this.bunifuTileButton2.LabelPosition = 41;
            this.bunifuTileButton2.LabelText = "Teachers";
            this.bunifuTileButton2.Location = new System.Drawing.Point(277, 192);
            this.bunifuTileButton2.Margin = new System.Windows.Forms.Padding(6);
            this.bunifuTileButton2.Name = "bunifuTileButton2";
            this.bunifuTileButton2.Size = new System.Drawing.Size(211, 170);
            this.bunifuTileButton2.TabIndex = 2;
            this.bunifuTileButton2.Click += new System.EventHandler(this.bunifuTileButton2_Click);
            // 
            // bunifuTileButton1
            // 
            this.bunifuTileButton1.BackColor = System.Drawing.Color.SeaGreen;
            this.bunifuTileButton1.color = System.Drawing.Color.SeaGreen;
            this.bunifuTileButton1.colorActive = System.Drawing.Color.MediumSeaGreen;
            this.bunifuTileButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuTileButton1.Font = new System.Drawing.Font("Century Gothic", 15.75F);
            this.bunifuTileButton1.ForeColor = System.Drawing.Color.White;
            this.bunifuTileButton1.Image = ((System.Drawing.Image)(resources.GetObject("bunifuTileButton1.Image")));
            this.bunifuTileButton1.ImagePosition = 20;
            this.bunifuTileButton1.ImageZoom = 50;
            this.bunifuTileButton1.LabelPosition = 41;
            this.bunifuTileButton1.LabelText = "Students";
            this.bunifuTileButton1.Location = new System.Drawing.Point(22, 192);
            this.bunifuTileButton1.Margin = new System.Windows.Forms.Padding(6);
            this.bunifuTileButton1.Name = "bunifuTileButton1";
            this.bunifuTileButton1.Size = new System.Drawing.Size(204, 170);
            this.bunifuTileButton1.TabIndex = 1;
            // 
            // AdminDashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1189, 630);
            this.Controls.Add(this.container);
            this.Controls.Add(this.top);
            this.Controls.Add(this.sidebar);
            this.Name = "AdminDashboard";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Dashboard";
            this.Load += new System.EventHandler(this.AdminDashboard_Load);
            this.sidebar.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.logo.ResumeLayout(false);
            this.logo.PerformLayout();
            this.top.ResumeLayout(false);
            this.top.PerformLayout();
            this.container.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel sidebar;
        private System.Windows.Forms.Panel top;
        private System.Windows.Forms.Panel container;
        private Bunifu.Framework.UI.BunifuFlatButton btnDashboard;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private Bunifu.Framework.UI.BunifuFlatButton txtUsers;
        private Bunifu.Framework.UI.BunifuFlatButton btnSections;
        private Bunifu.Framework.UI.BunifuFlatButton btnSubjects;
        private Bunifu.Framework.UI.BunifuFlatButton btnClasses;
        private Bunifu.Framework.UI.BunifuFlatButton btnTeachingStaff;
        private Bunifu.Framework.UI.BunifuFlatButton btnStudents;
        private System.Windows.Forms.Panel logo;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblUsername;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel1;
        private Bunifu.Framework.UI.BunifuTileButton bunifuTileButton4;
        private Bunifu.Framework.UI.BunifuTileButton bunifuTileButton3;
        private Bunifu.Framework.UI.BunifuTileButton bunifuTileButton2;
        private Bunifu.Framework.UI.BunifuTileButton bunifuTileButton1;
        private Bunifu.Framework.UI.BunifuFlatButton btnClassRoutine;
        private Bunifu.Framework.UI.BunifuTileButton bunifuTileButton5;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label7;
        private Bunifu.Framework.UI.BunifuTileButton bunifuTileButton6;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton1;
    }
}