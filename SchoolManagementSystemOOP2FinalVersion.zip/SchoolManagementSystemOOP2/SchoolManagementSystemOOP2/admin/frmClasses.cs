﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data.Sql;
//using System.Data;

namespace SchoolManagementSystemOOP2.admin
{
    public partial class frmClasses : UserControl
    {

        private DataAccess Da { set; get; }
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-C8UR0SS;Initial Catalog=SchoolManagement;Integrated Security=True");
        private SqlDataAdapter Rda { set; get; }
        SqlDataReader dr;
        SqlCommand cmd;
        int selectedRow;
        string autoId;
        public frmClasses()
        {
            InitializeComponent();
            this.Da = new DataAccess();
            
            this.Rda = new SqlDataAdapter();
            cmd = new SqlCommand();
            GenerateID();
            DisplayData();
        }
        public void GenerateID()
        {



            string query = "select class_id from classes order by class_id Desc";
            con.Open();
            cmd = new SqlCommand(query, con);
            dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                int id = int.Parse(dr[0].ToString()) + 1;
                autoId = id.ToString("000");
            }
            else if (Convert.IsDBNull(dr))
            {
                autoId = ("001");
            }
            else
            {
                autoId = ("001");
            }
            con.Close();
            txtClassId.Text = autoId.ToString();
        }


        private void btnSave_Click(object sender, EventArgs e)
        {
            DataSet ds = Da.ExecuteQuery("select name from classes where name ='" + this.txtClassName.Text + "' ");
            DataTable dt = new DataTable();
            // dt = new DataTable();
            int i = ds.Tables[0].Rows.Count;

            if (i > 0)
            {
                MessageBox.Show("Class already exist");

            }


            else
            {

                ds = Da.ExecuteQuery("insert into classes values('" + this.txtClassId.Text + "','" + this.txtClassName.Text + "', '" + this.cmbStandard.Text + "')");
                MessageBox.Show("Class Created");
                DisplayData();
                GenerateID();

            }
        }

        private void Panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Panel4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void dgw_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            selectedRow = e.RowIndex;
            DataGridViewRow row = dgv.Rows[selectedRow];
            txtClassId.Text = row.Cells[0].Value.ToString();
            txtClassName.Text = row.Cells[1].Value.ToString();
            cmbStandard.Text = row.Cells[2].Value.ToString(); 
        }
        public void DisplayData()
        {
            DataSet ds = Da.ExecuteQuery("select * from classes");
            this.dgv.AutoGenerateColumns = false;
            this.dgv.DataSource = ds.Tables[0];
        }
        private void panel7_Paint(object sender, PaintEventArgs e)
        {
            
        }
        private void PopulateGridView(string sql)
        {
            var ds = Da.ExecuteQuery(sql);
            this.dgv.AutoGenerateColumns = false;
            this.dgv.DataSource = ds.Tables[0];
        }
        private void Panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnNew_Click(object sender, EventArgs e)
        {

        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            string query = "update classes SET name = '" + this.txtClassName.Text + "' , status = '" + this.cmbStandard.Text + "' where class_id = '" + this.txtClassId.Text + "'";

            int rowCount = this.Da.ExecuteUpdateQuery(query);
            if (rowCount == 1)
            {
                MessageBox.Show("updated successfully");
            }
            else
            {
                MessageBox.Show("failed");
            }

            DisplayData();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            DataSet ds = Da.ExecuteQuery("delete from classes where class_id = '"+txtClassId.Text+"' ");
            MessageBox.Show("Deleted");
            DisplayData();
            GenerateID();
        }

        private void txtSearchByClass_KeyPress(object sender, KeyPressEventArgs e)
        {
            string query = "select * from classes where name like  '" + this.txtSearch.Text + "%' ";
            this.PopulateGridView(query);
        }
    }
}
