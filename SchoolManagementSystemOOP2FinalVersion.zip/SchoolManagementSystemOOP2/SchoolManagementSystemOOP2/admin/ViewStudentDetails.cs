﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SchoolManagementSystemOOP2.admin
{
    public partial class ViewStudentDetails : Form
    {
        DataAccess Da { set; get; }
        public ViewStudentDetails()
        {
            InitializeComponent();
            Da = new DataAccess();
            DataSet ds;
        }

        private void ViewStudentDetails_Load(object sender, EventArgs e)
        {
            
        }

        private void metroTextBox1_Click(object sender, EventArgs e)
        {

        }

        private void txtStuId_Click(object sender, EventArgs e)
        {

        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            
            DataSet ds = Da.ExecuteQuery("delete from student where student_id = '" + txtStuId.Text + "' ");
            ds = Da.ExecuteQuery("delete from users username = '" + txtUserName.Text + "' ");
            MessageBox.Show("Deleted");
            
        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {

            string query = "update student SET student_id = '" + this.txtStuId.Text + "' , firstname ='" + this.txtFirstName.Text + "', lastname = '" + this.txtLastName.Text + "' , email = '" + this.txtEmail.Text + "', username = '" + this.txtUserName.Text + "', gender = '" + this.cmbGender.Text + "', dob = '" + this.dtpDob.Text + "', fathername = '" + this.txtFatherName.Text + "', mothername = '" + this.txtMotherName.Text + "', password = '" + this.txtConfirmPassword.Text + "', status = '" + this.cmbStatus.Text + "', dor = '" + this.dtpDor.Text + "', phonenumber = '" + this.txtPhoneNumber.Text + "',class = '" + this.cmbClass.Text + "', section = '" + this.cmbSection.Text + "' where student_id = '"+this.txtStuId.Text+"' ";
            int rowCount = this.Da.ExecuteUpdateQuery(query);
                if(rowCount == 1)
            {
                MessageBox.Show("updated successfully");
            }
            else
            {
                MessageBox.Show("failed");
            }
           
        }
    }
}
