﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace SchoolManagementSystemOOP2.admin
{
    public partial class frmSubjects : Form
    {
        private DataAccess Da { set; get; }
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-C8UR0SS;Initial Catalog=SchoolManagement;Integrated Security=True");
        private SqlDataAdapter Rda { set; get; }
        SqlDataReader dr;
        SqlCommand cmd;
        int selectedRow;
        string autoId;
        public frmSubjects()
        {
            InitializeComponent();
            this.Da = new DataAccess();

            this.Rda = new SqlDataAdapter();
            cmd = new SqlCommand();
            GenerateID();
            DisplayData();
            classCombobox();
        }
        public void GenerateID()
        {



            string query = "select subject_id from subject order by subject_id Desc";
            con.Open();
            cmd = new SqlCommand(query, con);
            dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                int id = int.Parse(dr[0].ToString()) + 1;
                autoId = id.ToString("000");
                con.Close();
            }
            else if (Convert.IsDBNull(dr))
            {
                autoId = ("001");
            }
            else
            {
                autoId = ("001");
            }
            con.Close();
            txtSubjectId.Text = autoId.ToString();
        }
        public void classCombobox()
        {
            cmbClass.Items.Clear();
            con.Open();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select name from classes";
            cmd.ExecuteNonQuery();


            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);

            foreach (DataRow dr in dt.Rows)
            {
                cmbClass.Items.Add(dr["name"].ToString());
            }
            con.Close();
        }
        public void DisplayData()
        {
            DataSet ds = Da.ExecuteQuery("select * from subject");
            this.dgv.AutoGenerateColumns = false;
            this.dgv.DataSource = ds.Tables[0];
        }
        private void frmSubjects_Load(object sender, EventArgs e)
        {

        }
        private void PopulateGridView(string sql)
        {
            var ds = Da.ExecuteQuery(sql);
            this.dgv.AutoGenerateColumns = false;
            this.dgv.DataSource = ds.Tables[0];
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            DataSet ds = Da.ExecuteQuery("select code from subject where code ='" + this.txtSubjectCode.Text + "' ");
            DataTable dt = new DataTable();
            // dt = new DataTable();
            int i = ds.Tables[0].Rows.Count;


            if (i > 0)
            {
                MessageBox.Show("Subject already created");

            }


            else
            {

                ds = Da.ExecuteQuery("insert into subject values('" + this.txtSubjectId.Text + "','" + this.txtSubjectCode.Text + "','" + this.txtSubjectName.Text + "', '" + this.cmbClass.Text + "')");
                MessageBox.Show("Subject Created");
                DisplayData();
                GenerateID();


            }
        }

        private void dgv_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int selectedRow = e.RowIndex;
            DataGridViewRow row = dgv.Rows[selectedRow];
            txtSubjectId.Text = row.Cells[0].Value.ToString();
            txtSubjectCode.Text = row.Cells[1].Value.ToString();
            txtSubjectName.Text = row.Cells[2].Value.ToString();
            cmbClass.Text = row.Cells[3].Value.ToString();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            DataSet ds = Da.ExecuteQuery("delete from subject where subject_id = '" + txtSubjectId.Text + "' ");
            MessageBox.Show("Deleted");
            DisplayData();
            GenerateID();
        }
 
        private void txtSearch_KeyPress(object sender, KeyPressEventArgs e)
        {
            string query = "select * from subject where code like  '" + this.txtSearch.Text + "%' ";
            this.PopulateGridView(query);
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {

            // DataSet ds = Da.ExecuteQuery("update subject set code = '" + this.txtSubjectCode.Text + "' & name ='" + this.txtSubjectName.Text + "'   where subject_id ='"+this.txtSubjectId+"' ");
            string query = "update subject SET code = '" + this.txtSubjectCode.Text + "' , name = '" + this.txtSubjectName.Text + "' , class = '"+this.cmbClass.Text+"'  where subject_id = '" + this.txtSubjectId.Text + "' ";

            int rowCount = this.Da.ExecuteUpdateQuery(query);
            if (rowCount == 1)
            {
                MessageBox.Show("updated successfully");
            }
            else
            {
                MessageBox.Show("failed");
            }

            DisplayData();
        }
    }
}
