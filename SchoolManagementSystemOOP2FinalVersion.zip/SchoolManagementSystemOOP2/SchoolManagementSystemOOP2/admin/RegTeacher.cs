﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using SchoolManagementSystemOOP2.admin;

namespace SchoolManagementSystemOOP2.admin
{
    public partial class RegTeacher : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-C8UR0SS;Initial Catalog=SchoolManagement;Integrated Security=True");
        private DataAccess Da { set; get; }
        private SqlDataAdapter Rda { set; get; }
        SqlDataReader dr;
        SqlCommand cmd;
        public RegTeacher()
        {
            InitializeComponent();
            Da = new DataAccess();
            GenerateID();
        }
        public void GenerateID()
        {
            try
            {

                Da = new DataAccess();

                string sql = "select MAX(teacher_id) from teacher";
                cmd = new SqlCommand(sql, con);
                con.Open();

                var maxid = cmd.ExecuteScalar() as string;


                if (maxid == null)
                {
                    txtTeacherId.Text = "T-000001";

                }
                else
                {
                    int intval = int.Parse(maxid.Substring(2, 6));
                    intval++;
                    txtTeacherId.Text = string.Format("T-{0:000000}", intval);

                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            con.Close();


        }

        private void RegTeacher_Load(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void btnUp_Click(object sender, EventArgs e)
        {
            OpenFileDialog open = new OpenFileDialog();
            open.Filter = "Image Files(*.jpg; *.jpeg; *.gif; *.bmp; *.png)|*.jpg; *.jpeg; *.gif; *.bmp;*.png";
            if (open.ShowDialog() == DialogResult.OK)
            {
                
                pictureBox.Image = new Bitmap(open.FileName);
                
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (txtFirstName.Text == "")
            {
                MessageBox.Show("Please Enter First Name");
            }
            else if (txtLastName.Text == "")
            {
                MessageBox.Show("Please Enter Last Name");
            }
            else if (txtEmail.Text == "")
            {
                MessageBox.Show("Please Enter Email");
            }
            else if (txtUserName.Text == "")
            {
                MessageBox.Show("Please Enter UserName");
            }
         
            else if (txtPhoneNumber.Text == "")
            {
                MessageBox.Show("Please Enter Phone Number");
            }
            else if (txtPassword.Text == "")
            {
                MessageBox.Show("Please Enter Password");
            }
            else if (txtPassword.Text.Equals(txtConfirmPassword.Text) == false)
            {
                MessageBox.Show("Password does not match");
            }



            else
            {

                DataSet ds = Da.ExecuteQuery("select username from teacher where username='" + this.txtUserName.Text + "' ");
                DataTable dt = new DataTable();
                // dt = new DataTable();
                int i = ds.Tables[0].Rows.Count;

                if (i > 0)
                {
                    MessageBox.Show("username already Registered");

                }
                


                else
                {

                    ds = Da.ExecuteQuery("insert into teacher values('" + this.txtTeacherId.Text + "','" + this.txtFirstName.Text + "', '" + this.txtLastName.Text + "' , '" + this.txtEmail.Text + "','" + this.txtUserName.Text + "','" + this.cmbGender.Text + "','" + this.dtpDob.Text + "','" + this.txtSalary.Text + "','" + this.txtEducation.Text + "','" + this.txtConfirmPassword.Text + "','" + this.cmbStatus.Text + "','" + this.dtpDor.Text + "','" + this.txtPhoneNumber.Text + "','" + pictureBox.Image + "')");

                    ds = Da.ExecuteQuery("insert into users values( '" + this.txtUserName.Text + "','" + this.txtConfirmPassword.Text + "','" + this.student.Text + "' )");
                    MessageBox.Show("Teacher Registered");
                    GenerateID();
                    
                }
                

            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            DataSet ds = Da.ExecuteQuery("delete from teacher where teacher_id = '" + txtTeacherId.Text + "' ");
            MessageBox.Show("Deleted");
            //DisplayData();
            GenerateID();
        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
