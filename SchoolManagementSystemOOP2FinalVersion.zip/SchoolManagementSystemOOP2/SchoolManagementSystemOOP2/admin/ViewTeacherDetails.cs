﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SchoolManagementSystemOOP2.admin
{

    
    public partial class ViewTeacherDetails : Form
    {
        private DataAccess Da { set; get; }
        public ViewTeacherDetails()
        {
            InitializeComponent();
            Da = new DataAccess();

        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            string query = "update teacher SET teacher_id = '" + this.txtTeacherId.Text + "' , firstname ='" + this.txtFirstName.Text + "', lastname = '" + this.txtLastName.Text + "' , email = '" + this.txtEmail.Text + "', username = '" + this.txtUserName.Text + "', gender = '" + this.cmbGender.Text + "', dob = '" + this.dtpDob.Text + "', salary = '" + this.txtSalary.Text + "', education = '" + this.txtEducation.Text + "', password = '" + this.txtConfirmPassword.Text + "', status = '" + this.cmbStatus.Text + "', dor = '" + this.dtpDor.Text + "', phone = '" + this.txtPhoneNumber.Text + "' where teacher_id = '" + this.txtTeacherId.Text + "' ";
            int rowCount = this.Da.ExecuteUpdateQuery(query);
            if (rowCount == 1)
            {
                MessageBox.Show("updated successfully");
            }
            else
            {
                MessageBox.Show("failed");
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            DataSet ds = Da.ExecuteQuery("delete from teacher where teacher_id = '" + txtTeacherId.Text + "' ");
            ds = Da.ExecuteQuery("delete from users username = '" + txtUserName.Text + "' ");
            MessageBox.Show("Deleted");
        }
    }
}
