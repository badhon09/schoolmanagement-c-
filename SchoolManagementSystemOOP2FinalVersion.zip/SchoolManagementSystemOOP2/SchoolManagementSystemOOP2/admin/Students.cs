﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SchoolManagementSystemOOP2.Service;
using SchoolManagementSystemOOP2.admin;
using System.Data.SqlClient;

namespace SchoolManagementSystemOOP2
{
    public partial class Students : Form
    {
        private DataAccess Da { set; get; }
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-C8UR0SS;Initial Catalog=SchoolManagement;Integrated Security=True");
        private SqlDataAdapter Rda { set; get; }
        SqlDataReader dr;
        public SqlCommand cmd;
        public Students()
        {
            InitializeComponent();
            Da = new DataAccess();
            DataTable dt;
            DisplayData();
           // SectionCombobox();
            classCombobox();
            cmd = new SqlCommand();
            Rda = new SqlDataAdapter();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        public void classCombobox()
        {
            //cmbClass.Items.Clear();

            string sql = "select * from classes ";

            cmd = new SqlCommand(sql, con);
            SqlDataReader rd;
            try
            {
                con.Open();
                rd = cmd.ExecuteReader();
                while (rd.Read())
                {
                    string clname = rd.GetString(1);
                    cmbClass.Items.Add(clname);
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            con.Close();
        }

        private void bunifuTileButton1_Click(object sender, EventArgs e)
        {
            RegStudent rs = new RegStudent();
            rs.Visible = true;
        }

        private void tablePane_Paint(object sender, PaintEventArgs e)
        {

        }

        private void ShowTable(Control controls)
        {
            tablePane.Controls.Clear();
            //controls.TopLevel = false;
            tablePane.Controls.Add(controls);
            //controls.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            controls.Dock = DockStyle.Fill;
            controls.Show();

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            
        }
   

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            DataSet ds = Da.ExecuteQuery("select * from student");
            this.dgvStudent.AutoGenerateColumns = false;
            this.dgvStudent.DataSource = ds.Tables[0];
           // this.dgvStudent.AutoGenerateColumns = false;

        }
       public void DisplayData()
        {
            DataSet ds = Da.ExecuteQuery("select * from student");
            this.dgvStudent.AutoGenerateColumns = false;
            this.dgvStudent.DataSource = ds.Tables[0];


        }

        private void metroComboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            DataSet ds = Da.ExecuteQuery("select * from student where class = '"+this.cmbClass.Text+"'");
            this.dgvStudent.AutoGenerateColumns = false;
            this.dgvStudent.DataSource = ds.Tables[0];


        }

        private void dgvStudent_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            

            int selectedRow = e.RowIndex;
            DataGridViewRow row = dgvStudent.Rows[selectedRow];
            ViewStudentDetails v = new ViewStudentDetails();


            
            StudentsDetails.studentId= row.Cells[0].Value.ToString();
            StudentsDetails.firstName = row.Cells[1].Value.ToString();
            StudentsDetails.lastName = row.Cells[2].Value.ToString();
            StudentsDetails.email = row.Cells[4].Value.ToString();
            StudentsDetails.userName = row.Cells[3].Value.ToString();
            StudentsDetails.gender = row.Cells[5].Value.ToString();
            StudentsDetails.className = row.Cells[6].Value.ToString();
            StudentsDetails.dor = row.Cells[7].Value.ToString();
            StudentsDetails.dob = row.Cells[8].Value.ToString();
            StudentsDetails.section = row.Cells[9].Value.ToString();
            StudentsDetails.fatherName = row.Cells[10].Value.ToString();
            StudentsDetails.motherName = row.Cells[11].Value.ToString();
            StudentsDetails.password = row.Cells[12].Value.ToString();
            StudentsDetails.status = row.Cells[13].Value.ToString();
            StudentsDetails.phone = row.Cells[14].Value.ToString();
            //v.pictureBox.Image = row.Cells[15].Value;


            v.txtStuId.Text = StudentsDetails.studentId;
            v.txtFirstName.Text = StudentsDetails.firstName;
            v.txtLastName.Text = StudentsDetails.lastName;
            v.txtEmail.Text = StudentsDetails.email;
            v.txtUserName.Text = StudentsDetails.userName;
            v.cmbGender.Text=StudentsDetails.gender;
            v.cmbClass.Text = StudentsDetails.className;
            v.dtpDor.Text = StudentsDetails.dor;
            v.dtpDob.Text = StudentsDetails.dob;
            v.cmbSection.Text = StudentsDetails.section;
            v.txtFatherName.Text = StudentsDetails.fatherName;
            v.txtMotherName.Text = StudentsDetails.motherName;
            v.txtConfirmPassword.Text = StudentsDetails.password;
            v.txtPhoneNumber.Text = StudentsDetails.phone;
            v.cmbStatus.Text = StudentsDetails.status;
           // v.pictureBox.Image = StudentsDetails.image;






            v.Show();



            //rgs.txtStuId.Text = this.dgvStudent.CurrentRow.Cells[0].Value.ToString();
           // txtFirstName.Text = row.Cells[1].Value.ToString();
            // rgs.txtFirstName.Text = this.dgvStudent.CurrentRow.Cells[1].Value.ToString();
            //rgs.txtEmail.Text = row.Cells[3].Value.ToString();
            //rgs.txtUserName.Text = row.Cells[4].Value.ToString();
            //rgs.txtFatherName.Text = row.Cells[5].Value.ToString();
            //rgs.txtMotherName.Text = row.Cells[6].Value.ToString();
            
        }

        private void Students_Load(object sender, EventArgs e)
        {

        }
 
        private void PopulateGridView(string sql)
        {
            var ds = Da.ExecuteQuery(sql);
            this.dgvStudent.AutoGenerateColumns = false;
            this.dgvStudent.DataSource = ds.Tables[0];
        }
        private void txtSearch_KeyPress(object sender, KeyPressEventArgs e)
        {
           
            string query="select * from student where username like  '"+this.txtSearch.Text+"%' ";
            this.PopulateGridView(query);
            
        }

        private void metroButton1_Click(object sender, EventArgs e)
        {
            DataSet ds = Da.ExecuteQuery("select * from student where username like  '" + this.txtSearch.Text + "' ");
            DisplayData();
        }

        private void txtSearch_Click(object sender, EventArgs e)
        {

        }

        private void metroButton1_Click_1(object sender, EventArgs e)
        {
            DisplayData();
        }
    }
}
