﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SchoolManagementSystemOOP2.Service
{
    class StudentsDetails
    {
        public static string studentId;
        public static string firstName;
        public static string lastName;
        public static string email;
        public static string userName;
        public static string fatherName;
        public static string motherName;
        public static string phone;
        public static string status;
        public static string className;
        public static string gender;
        public static string section;
        public static string dob;
        public static string password;
        public static string dor;
        public static string image;
    }
}
