﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SchoolManagementSystemOOP2.Repository;
using SchoolManagementSystemOOP2.Entities;

namespace SchoolManagementSystemOOP2.Service
{
    class LoginService
    {
        LoginRepository loginRepo;
        public LoginService()
        {
            loginRepo = new LoginRepository();
        }

        public int LoginValidation(string username, string password)
        {
            return loginRepo.Validation(new Users() { Username = username, Password = password });
        }
    }
}
