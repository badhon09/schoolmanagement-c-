﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SchoolManagementSystemOOP2.Service
{
    class global
    {
        private static string userName;
        public static string userType;
        public static string UserName
        {
            set
            {
                userName = value;
            }
            get
            {
                return userName;
            }
        }

    }
}
