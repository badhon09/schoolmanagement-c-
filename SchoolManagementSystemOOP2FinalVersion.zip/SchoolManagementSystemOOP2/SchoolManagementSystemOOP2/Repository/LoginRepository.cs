﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using SchoolManagementSystemOOP2.Entities;
using SchoolManagementSystemOOP2.Service;

namespace SchoolManagementSystemOOP2.Repository
{
    class LoginRepository
    {
        DataAccess Da { set; get; }

        public LoginRepository()
        {
            Da = new DataAccess();
        }

        public int Validation(Users user)
        {
            Da = new DataAccess();
            string sql = "SELECT * FROM users WHERE username='" + user.Username + "' AND password='" + user.Password + "'";
            SqlDataReader reader = Da.GetData(sql);
            
            
            if (reader.HasRows)
            {
                reader.Read();
                if (reader[2].ToString() == "Student")
                {
                    return 1;
                }
                else if (reader[2].ToString() == "Admin")
                {
                    
                    
                    return 2;
                }
                else if (reader[2].ToString() == "Teacher")
                {
                    return 3;
                }
            }

            else
            {
                 
                return 0;
            }
            return 0;
        }

    }
}
